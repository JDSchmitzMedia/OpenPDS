var Resource = require('deployd/lib/resource')
  , Collection = require('deployd/lib/resources/collection')
  , util = require('util');

function Funf(options) {
  Resource.apply(this, arguments);
}
util.inherits(Funf, Collection);
module.exports = Funf;

Funf.prototype.handle = function (ctx, next) {
  if(ctx.req && ctx.req.method !== 'GET') return next();
  console.log('should call oauth');
  ctx.done(null, {hello: 'world'});
}

Funf.dashboard = {
  path: __dirname , //The absolute path to your front-end files
  pages: ["API"], // Optional; these pages will appear on the sidebar.
  scripts: [ 
    '/js/lib/backbone.js', //relative paths to extra JavaScript files you would like to load
    '/js/lib/jquery-ui.js'
  ]
};
